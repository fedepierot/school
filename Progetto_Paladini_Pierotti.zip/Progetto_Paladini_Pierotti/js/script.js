const IPlength= 35;
var RegExpipv4= /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
var ip= $("#ip");
var subnet= $("#subnet");
var IPbin, subnetDec, subnetBin, netIP, netIPDec, x, interv;

$(document).ready(function(){
    $("#inviaBtn").click(invia);
    $("#f1").click(primaParte);
    $("#f2").click(secondaParte);
    $("#f3").click(terzaParte);
    $("#f4").click(quartaParte);
});

function invia(){
    clearInterval(interv);
    subnetDec= "";
    $("#f1").show();
    $("#f2").show();

    $("#bin").hide();
    $("#dec").hide();
    $("#netIP").hide();
    $("#broadcastIP").hide();
    $("#nHost").hide()
    
    $(".errore").remove();
    var err= false;
    if(subnet.val()<1 || subnet.val()>31){
        $("#subnet").after("<label class='errore'> Subnet errata </label>");
        err= true;
    }
    if(ip.val()=="" || !RegExpipv4.test(ip.val()) || ip.val()=="0.0.0.0" || ip.val()=="255.255.255.255"){
        $("#subnet").after("<label class='errore'> IP errato </label>");
        err= true;
    }
    
    if(!err){
        subnetDecimale(); //trasformo la subnet in decimale
        $("#dec").show();
        $("#IPDec").html(ip.val());
        $("#subnetDec").html(subnetDec);
    }
}

function primaParte(){
    $("#bin").show();
    $("#f1").hide();

    IPbin= decimaleBinario(ip.val()); //traformo l'ip in binario    
    subnetBin= decimaleBinario(subnetDec); //trasformo la subnet in binario

    x= parseInt(subnet.val())+parseInt(subnet.val()/8);
    $("#IPBin").html('<span class="blu">'+IPbin.substring(0, x)+'</span>'+IPbin.substring(x, IPlength));
    $("#subnetBin").html('<span class="blu">'+subnetBin.substring(0, x)+'</span>'+subnetBin.substring(x, IPlength));
}

function secondaParte(){
    $("#f2").hide();
    $("#netIP").show();

    x= 0;
    netIP= funzReteIP(IPbin, subnetBin);
    interv= setInterval(coloraTesto, 300); 

    netIPDec= binarioDecimale(netIP);
    $("#netIPdec").html(netIPDec);
}

function terzaParte(){
    x= parseInt(subnet.val())+parseInt(subnet.val()/8);
    $("#f3").hide();

    $("#broadcastIP").show();
    broadcastIP= funzBroadcastIP(IPbin, subnet.val());
    $("#broadcastIPbin").html('<span class="blu">'+broadcastIP.substring(0, x)+'</span>');
    interv= setInterval(coloraSubnet, 300);
    broadcastIPDec= binarioDecimale(broadcastIP);
    $("#broadcastIPdec").html(broadcastIPDec);
}

function quartaParte(){
    $("#f4").hide();
    $("#nHost").show();

    nHost=parseInt(32-subnet.val());
    $("#num").html("Numero di host indirizzabili con "+nHost+" bit: 2^"+nHost+"-2"+"= "+(Math.pow(2, nHost)-2));
}

function decimaleBinario(s){
    var nBin= "", zero;
    s+= ".";
    var x, y, a= 0, n=""; 
    for(var i= 0; i<4; i++){
        zero="";
        y= s.indexOf(".", a);
        x= parseInt(s.substring(a, y));

        var n= (x%2).toString();
        while(x>1){
            x= parseInt(x/2);
            n= (x%2)+n;
        }

        for(var j= 0; j<(8-n.length); j++){
            zero+= "0";
        }

        nBin= nBin+"."+zero+n;
        a= y+1;
    }

    nBin= nBin.substring(1, IPlength+1);
    return nBin;
}

function subnetDecimale(){
    x= subnet.val();
    if(x<=8) subnetDec= bit(x)+".0.0.0";
    else{
        if(x<=16) subnetDec= "255."+bit(x-8)+".0.0";
        else{
            if(x<=24) subnetDec= "255.255."+bit(x-16)+".0";
            else subnetDec= "255.255.255."+bit(x-24);
        }
    }
}

function bit(subnetRimasta){
    var bitsubnet;
    subnetRimasta= parseInt(subnetRimasta);
    switch(subnetRimasta){
        case 1:
            bitsubnet= "128";
            break;
        case 2:
            bitsubnet= "192";
            break;
        case 3:
            bitsubnet= "224";
            break;
        case 4:
            bitsubnet= "240";
            break;
        case 5:
            bitsubnet= "248";
            break;
        case 6:
            bitsubnet= "252";
            break;
        case 7:
            bitsubnet= "254";
            break;
        case 8:
            bitsubnet= "255";
            break;    
    }
    return bitsubnet;
}

function funzReteIP(IP, subnet){
    var netIP= "";
    for(var i= 0; i<35; i++){
        if(IP[i]!=".")  netIP= netIP+(IP[i]&subnet[i]);
        else netIP= netIP+".";
    }
    return netIP;
}

function funzBroadcastIP(IP, subnet){
    var fineNetIP= parseInt(subnet)+parseInt(subnet/8);
    var broadcastIP= IP.substring(0, fineNetIP);
    for(var i= fineNetIP; i<35; i++){
        if(IP[i]!=".")  broadcastIP= broadcastIP+"1";
        else broadcastIP= broadcastIP+".";
    }

    return broadcastIP;
}

function binarioDecimale(s){
    s+= "."; 
    var nDec= "", x, y, a, somma;
    for(var i= 0; i<4; i++){
        somma= 0;
        y= s.indexOf(".", a);
        x= s.substring(a, y);

        for(var j= 0; j<8; j++){
            somma+= parseInt(x[j])*Math.pow(2, 7-j);
        }
        nDec+= somma+".";

        a= y+1;
    }

    nDec= nDec.substring(0, nDec.length-1);
    return nDec;
}

function coloraTesto(){
    if(x>=35){
        clearInterval(interv);
        setTimeout(function(){
            $("#IPBin").html(IPbin);
            $("#subnetBin").html(subnetBin);
            var z= parseInt(subnet.val())+parseInt(subnet.val())/8; 
            $("#netIPbin").html('<span class="blu">'+netIP.substring(0, z)+'</span>'+netIP.substring(z, IPlength));
            $("#netIPdec").show();
            $("#f3").show();
        }, 300);
    }
    else{
        $("#subnetBin").html(subnetBin.substring(0, x)+'<span class="rosso">'+subnetBin[x]+'</span>'+subnetBin.substring(x+1, IPlength));
        $("#IPBin").html(IPbin.substring(0, x)+'<span class="rosso">'+IPbin[x]+'</span>'+IPbin.substring(x+1, IPlength));
        $("#netIPbin").html(netIP.substring(0, x)+'<span class="rosso">'+netIP[x]+'</span>');
        x++;
    }  
}

function coloraSubnet(){
    var z= parseInt(subnet.val())+parseInt(subnet.val())/8;
    if(x>=34){
        clearInterval(interv);
        setTimeout(function(){
            $("#netIPbin").html('<span class="blu">'+netIP.substring(0, z)+'</span>'+netIP.substring(z, IPlength));
            $("#broadcastIPbin").html('<span class="blu">'+broadcastIP.substring(0, z)+'</span>'+broadcastIP.substring(z, IPlength));
            $("#broadcastIPdec").show();
            $("#f4").show();
        }, 300);
    }   
    $("#netIPbin").html('<span class="blu">'+netIP.substring(0, z)+'</span>'+netIP.substring(z, x)+'<span class="rosso">'+netIP[parseInt(x)]+'</span>'+netIP.substring(x+1, IPlength));
    $("#broadcastIPbin").html('<span class="blu">'+broadcastIP.substring(0, z)+'</span>'+broadcastIP.substring(z, x)+'<span class="rosso">'+broadcastIP[parseInt(x)]+'</span>');
    x++;
}

